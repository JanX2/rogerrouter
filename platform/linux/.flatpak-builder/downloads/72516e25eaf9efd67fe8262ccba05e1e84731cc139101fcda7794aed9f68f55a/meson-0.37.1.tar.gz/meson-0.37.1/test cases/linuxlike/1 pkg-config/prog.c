#include<zlib.h>

int main(int argc, char **argv) {
    void * something = deflate;
    if(something != 0)
        return 0;
    return 1;
}
