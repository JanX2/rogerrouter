int statlibfunc() {
    return 42;
}
