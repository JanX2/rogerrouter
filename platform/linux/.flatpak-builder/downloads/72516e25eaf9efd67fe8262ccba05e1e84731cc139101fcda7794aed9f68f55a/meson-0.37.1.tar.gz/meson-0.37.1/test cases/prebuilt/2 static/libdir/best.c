const char *msg() {
    return "I am the best.";
}
