#include<zlib.h>

int statlibfunc() {
    void * something = deflate;
    if(something != 0)
        return 0;
    return 1;
}
