#include"generated-gdbus.h"

int main(int argc, char **argv) {
    SampleComExample *s;
    s = sample_com_example_skeleton_new();
    g_object_unref(s);
    return 0;
}
