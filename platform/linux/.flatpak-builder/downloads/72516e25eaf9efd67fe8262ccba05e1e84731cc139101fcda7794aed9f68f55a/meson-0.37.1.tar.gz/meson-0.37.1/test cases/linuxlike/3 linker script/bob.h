#ifndef BOB_H_
#define BOB_H_

int bobMcBob();

#endif
