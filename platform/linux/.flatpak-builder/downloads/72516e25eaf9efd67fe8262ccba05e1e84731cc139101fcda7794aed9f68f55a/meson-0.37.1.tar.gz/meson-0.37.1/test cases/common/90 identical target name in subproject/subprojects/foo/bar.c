#include<stdio.h>

int main(int argc, char **argv) {
    printf("I'm a subproject bar.\n");
    return 0;
}
