#!/bin/sh

for i in *.c; do
  echo $i
done
