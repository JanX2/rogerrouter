#![crate_name = "stuff"]

pub fn explore() -> &'static str { "librarystring" }
