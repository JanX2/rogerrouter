int statlibfunc2() {
    return 18;
}
