extern crate stuff;

fn main() { println!("printing: {}", stuff::explore()); }
