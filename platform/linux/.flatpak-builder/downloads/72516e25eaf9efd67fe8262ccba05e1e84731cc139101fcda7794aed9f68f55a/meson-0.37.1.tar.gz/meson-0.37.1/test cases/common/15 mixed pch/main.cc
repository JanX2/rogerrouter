extern "C" int cfunc();

void func() {
    std::cout << "This is a function that fails to compile if iostream is not included."
              << std::endl;
}

int main(int argc, char **argv) {
    return cfunc();
}
