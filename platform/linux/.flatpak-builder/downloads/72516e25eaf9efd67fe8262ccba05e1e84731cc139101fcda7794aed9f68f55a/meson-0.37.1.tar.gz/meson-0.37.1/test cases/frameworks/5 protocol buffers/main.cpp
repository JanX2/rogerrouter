#include "defs.pb.h"

int main(int argc, char **argv) {
    GOOGLE_PROTOBUF_VERIFY_VERSION;
    Dummy *d = new Dummy;
    delete d;
    google::protobuf::ShutdownProtobufLibrary();
    return 0;
}
