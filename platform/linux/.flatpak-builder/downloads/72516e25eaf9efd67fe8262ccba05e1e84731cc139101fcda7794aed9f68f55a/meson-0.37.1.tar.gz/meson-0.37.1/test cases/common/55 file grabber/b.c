int funcb() { return 0; }
