int sub_lib_method(void);

int main() {
    return 1337 - sub_lib_method();
}
