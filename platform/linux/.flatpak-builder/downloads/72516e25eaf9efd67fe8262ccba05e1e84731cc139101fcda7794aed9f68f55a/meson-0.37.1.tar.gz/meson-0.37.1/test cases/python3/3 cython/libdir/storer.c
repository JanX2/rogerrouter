#include"storer.h"
#include<stdlib.h>

struct _Storer {
    int value;
};

Storer* storer_new() {
    Storer *s = malloc(sizeof(struct _Storer));
    s->value = 0;
    return s;
}

void storer_destroy(Storer *s) {
    free(s);
}

int storer_get_value(Storer *s) {
    return s->value;
}

void storer_set_value(Storer *s, int v) {
    s->value = v;
}
