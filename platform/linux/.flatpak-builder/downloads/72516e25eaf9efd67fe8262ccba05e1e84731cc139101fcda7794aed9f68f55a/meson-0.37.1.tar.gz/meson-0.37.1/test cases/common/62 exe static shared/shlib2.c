#include "subdir/exports.h"

int statlibfunc(void);
int statlibfunc2(void);

int DLL_PUBLIC shlibfunc2(void) {
    return statlibfunc() - statlibfunc2();
}
