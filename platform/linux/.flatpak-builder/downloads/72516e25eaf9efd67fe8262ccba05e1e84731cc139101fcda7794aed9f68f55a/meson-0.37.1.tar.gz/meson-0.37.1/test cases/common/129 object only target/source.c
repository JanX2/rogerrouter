int func1_in_obj() {
    return 0;
}
