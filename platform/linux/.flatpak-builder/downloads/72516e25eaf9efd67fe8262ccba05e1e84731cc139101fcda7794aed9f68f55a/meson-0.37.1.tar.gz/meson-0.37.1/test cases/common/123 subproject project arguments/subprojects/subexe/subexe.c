#ifdef PROJECT_OPTION
#error
#endif

#ifdef PROJECT_OPTION_1
#error
#endif

#ifndef GLOBAL_ARGUMENT
#error
#endif

#ifndef SUBPROJECT_OPTION
#error
#endif

#ifdef OPTION_CPP
#error
#endif

int main(int argc, char **argv) {
    return 0;
}
