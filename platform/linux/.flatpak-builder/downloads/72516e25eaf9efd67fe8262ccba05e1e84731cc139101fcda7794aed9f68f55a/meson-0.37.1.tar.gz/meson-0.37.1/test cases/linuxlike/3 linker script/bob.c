#include"bob.h"

int hiddenFunction() {
    return 42;
}

int bobMcBob() {
    return hiddenFunction();
}
