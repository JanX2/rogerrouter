int testfunc(void) { return 0; }
