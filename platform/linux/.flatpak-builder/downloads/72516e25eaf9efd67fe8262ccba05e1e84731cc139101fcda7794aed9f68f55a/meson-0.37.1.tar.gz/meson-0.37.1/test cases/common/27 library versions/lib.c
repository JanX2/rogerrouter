int myFunc() {
    return 55;
}
