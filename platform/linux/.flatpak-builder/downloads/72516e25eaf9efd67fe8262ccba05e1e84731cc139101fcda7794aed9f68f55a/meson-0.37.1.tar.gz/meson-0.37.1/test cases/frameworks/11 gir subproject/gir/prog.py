#!/usr/bin/env python3
from gi.repository import MesonSub

if __name__ == "__main__":
    s = MesonSub.Sample.new("Hello, sub/meson/py!")
    s.print_message()
