fn main() {
    println!("rust compiler is working");
}
