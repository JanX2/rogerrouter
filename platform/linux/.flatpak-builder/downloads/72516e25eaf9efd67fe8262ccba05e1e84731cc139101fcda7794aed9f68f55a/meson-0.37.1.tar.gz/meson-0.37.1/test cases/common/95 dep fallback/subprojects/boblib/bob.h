#pragma once

#ifdef _MSC_VER
__declspec(dllimport)
#endif
const char* get_bob();
