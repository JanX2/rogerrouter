#include<stdio.h>
#include"version.h"

int main(int argc, char **argv) {
    printf("Version is %s.\n", version_string);
    return 0;
}
