#import<stdio.h>

class MyClass {
};

int main(int argc, char **argv) {
  return 0;
}

